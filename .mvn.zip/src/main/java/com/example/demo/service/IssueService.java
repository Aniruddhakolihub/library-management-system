package com.example.demo.service;

import com.example.demo.entity.IssueRecord;
import com.example.demo.entity.Student;
import com.example.demo.repository.IssueRepository;
import com.example.demo.repository.StudentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class IssueService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private IssueRepository issueRepository;

    // Issue Book
    public IssueRecord issueBook(IssueRecord record){

        Student student = studentRepository.findByStudentName(
                record.getStudent().getStudentName()
        );

        if(student == null){

            student = new Student();
            student.setStudentName(record.getStudent().getStudentName());
            student.setBooksTaken(1);

        }else{

            student.setBooksTaken(student.getBooksTaken() + 1);

        }

        studentRepository.save(student);

        record.setStudent(student);

        record.setIssueDate(LocalDate.now());

        return issueRepository.save(record);
    }

    // Get Issue History
    public List<IssueRecord> getAllIssuedBooks(){
        return issueRepository.findAll();
    }

    // Return Book
    public IssueRecord returnBook(Long id){

        IssueRecord record = issueRepository.findById(id).orElseThrow();

        record.setReturnDate(LocalDate.now());

        Student student = record.getStudent();

        if(student != null && student.getBooksTaken() > 0){

            student.setBooksTaken(student.getBooksTaken() - 1);

            studentRepository.save(student);

        }

        return issueRepository.save(record);
    }

    // - Delete Issue Record
    public void deleteIssue(Long id){

        issueRepository.deleteById(id);

    }

}