package com.example.demo.controller;

import com.example.demo.entity.IssueRecord;
import com.example.demo.service.IssueService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/issue")
public class IssueController {

    @Autowired
    private IssueService issueService;

    // Issue Book
    @PostMapping("/book")
    public IssueRecord issueBook(@RequestBody IssueRecord record){
        return issueService.issueBook(record);
    }

    // Get Issue History
    @GetMapping("/history")
    public List<IssueRecord> history(){
        return issueService.getAllIssuedBooks();
    }

    // Return Book
    @PutMapping("/return/{id}")
    public IssueRecord returnBook(@PathVariable Long id){
        return issueService.returnBook(id);
    }

    // Delete Issue Record
    @DeleteMapping("/delete/{id}")
    public void deleteIssue(@PathVariable Long id){
        issueService.deleteIssue(id);
    }

}